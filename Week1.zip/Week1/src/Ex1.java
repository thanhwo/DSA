import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        int len = line.length();
        for (int i = len - 1; i >=0 ; i-- ){
            System.out.print(line.charAt(i));
        }
        scanner.close();
    }
}
