import java.util.Scanner;

public class Ex3 {
    public static void swap(int[] a, int i, int j){
        a[i] = a[i] ^ a[j];
        a[j] = a[j] ^ a[i];
        a[i] = a[j] ^ a[i];
    }
    public static void sort(int[] a, int n){
        for (int i =0; i < n; i++){
            for (int j = i+1; j < n; j++){
                if(a[i] > a[j]){
                    swap(a,i,j);
                }
            }
        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] a = new int[n];
        for(int i = 0; i < n; i++){
            a[i] = scanner.nextInt();
        }
        sort(a,n);
        for(int x : a){
            System.out.print(x + " ");
        }
        scanner.close();
    }
}
