import java.util.Scanner;

public class Ex4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double max , min;
        double[] a = new double[5];
        a[0] = scanner.nextDouble();
        max = a[0];
        min = a[0];
        for (int i = 1; i < 5; i++){
            a[i] = scanner.nextDouble();
            if (a[i] < min)
                min = a[i];
            if (a[i] > max)
                max = a[i];
        }
        System.out.print(max + min);
    }
}
